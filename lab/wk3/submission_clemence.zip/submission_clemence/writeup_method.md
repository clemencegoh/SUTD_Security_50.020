# Method used to crack code

1. Segment the hashes into weak, moderate and strong
2. Use rainbow tables of varying lengths to test for each file
